public interface SortCollection {
    public void add(Object data);
    public void remove(Object data);
    public void contain(Object data);
    public boolean isEmpty();
    public int size();


}
