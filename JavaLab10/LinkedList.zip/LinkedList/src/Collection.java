public interface Collection {
    public void add(Object element);
    public void remove(Object element);
    public boolean contain(Object element);
    public boolean isEmpty();
    public int size();
}
