import javax.swing.JFrame;
public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setSize(300, 400);
        frame.setTitle("Traffic light");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        LightComponent component = new LightComponent();
        frame.add(component);
        frame.setVisible(true);
    }
}